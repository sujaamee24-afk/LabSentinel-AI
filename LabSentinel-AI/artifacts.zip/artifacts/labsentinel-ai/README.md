# LabSentinel AI — Demo Mode

## Run

Open the **LabSentinel AI** artifact and use its **Run** button. The workspace is a client-only React/Vite application; no API server is required for this demo.

For a local workspace checkout, from `artifacts/labsentinel-ai` run:

```sh
pnpm dev
```

## Demo limits

This is a frontend-only demonstration. It has no backend, connected sensor, actual computer-vision model, LLM, or AI integration. Sensor values and time-series are illustrative simulations; people counts are fixed simulated values. Manual descriptions and notes are user-provided. Uploaded images are previewed but **not analyzed**. Audio files and microphone recordings are attachments only and are not automatically transcribed. Any optional transcript is typed by the user.

Risk explanations use a deterministic demo rules engine and editable illustrative thresholds—not certified laboratory limits. Do not use reports to make operational safety decisions. Follow your institution’s emergency procedures and consult qualified safety professionals.

Thresholds, selected locale, current demo readings, and incident reports are stored in this browser’s localStorage. Resetting demo history is destructive; clearing browser storage also removes saved data.
